import express, { Router } from "express";
import cors from "cors";
import jsonControlRouter from "./routes/jsonControlRouter";
import { errorHandler } from "./errorHandler";

const app = express();
app.use(express.json());
const port = 3004;

app.use(
  cors({
    origin: "*",
    methods: ["GET", "POST", "DELETE", "PUT"],
    allowedHeaders: ["*"],
  })
);

app.use("/jsonControl", jsonControlRouter);

app.use(errorHandler);

app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
